"""Bounded reconnects for explicitly read-only calls; never wraps a write."""
import time


class ReadSession:
    def __init__(self,service,attempts=2):
        if type(attempts) is not int or not 1<=attempts<=3:raise ValueError('read attempts must be1..3')
        self.service=service;self.attempts=attempts;self.gateway=None;self.identity=None;self.retries=[]

    @staticmethod
    def key(info):return (info['ip'],info['dali_mac'].lower(),info['dali_firmware'])

    def connect(self):
        g,info=self.service._open()
        if self.identity is not None and self.key(info)!=self.key(self.identity):
            g.close();raise RuntimeError('Gateway identity changed during read retry; stopped')
        self.gateway=g;self.identity=info
        return info

    def read(self,method,*args,context=None):
        if not (method.startswith('read_') or method=='light_type'):
            raise ValueError('Only allowlisted read methods can be retried')
        for attempt in range(self.attempts):
            try:
                if self.gateway is None:self.connect()
                return getattr(self.gateway,method)(*args)
            except (TimeoutError,OSError) as exc:
                self.close()
                self.retries.append(dict(attempt=attempt+1,method=method,target=context,error=str(exc),at=time.time()))
                if attempt+1==self.attempts:raise
                time.sleep(.2*(attempt+1))

    def close(self):
        if self.gateway is not None:self.gateway.close();self.gateway=None
