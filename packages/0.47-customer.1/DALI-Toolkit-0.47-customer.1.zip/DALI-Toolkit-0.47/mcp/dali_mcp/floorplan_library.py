"""Independent immutable image/marker drafts. No bus or native application writes."""
import copy
import io
import json
import math
from pathlib import Path
import re
import time
import uuid
from .native_file import NativeFileController, _no_links, digest
from .native_cache import canonical
from .native_floorplan_file import NativeFloorplanFileController
from .project_floorplan import inspect_png, IMAGE_LIMIT

LIBRARY_IMAGE_LIMIT=40_000_000
LIBRARY_PIXEL_LIMIT=40_000_000
LIBRARY_SIDE_LIMIT=16384

def inspect_library_png(data):
    return inspect_png(data,byte_limit=LIBRARY_IMAGE_LIMIT,pixel_limit=LIBRARY_PIXEL_LIMIT,side_limit=LIBRARY_SIDE_LIMIT)

def native_asset_snapshot(controller,path,document):
    from .native_floorplan import inspect_native_floorplan
    summary=inspect_native_floorplan(document)
    if not summary['present']:return dict(state='no_floorplan'),None
    filename=summary['image_reference'];target=controller._asset_path(path,filename)
    if not target.exists():return dict(state='missing',filename=filename),None
    with target.open('rb') as f:data=f.read(LIBRARY_IMAGE_LIMIT+1)
    return dict(state='present',filename=filename,metadata=inspect_library_png(data)),data


def key(mark):return (mark['ch'],mark['addr'])


def validate_marks(marks,coordinates=True):
    if type(marks) is not list or len(marks)>128:raise ValueError('marks must contain0..128 entries')
    seen=set()
    for m in marks:
        if type(m) is not dict or type(m.get('ch')) is not int or m['ch'] not in (1,2):raise ValueError('mark ch must be1 or2')
        if type(m.get('addr')) is not int or not 0<=m['addr']<=63:raise ValueError('mark addr must be0..63')
        if key(m) in seen:raise ValueError('duplicate channel/address marker')
        seen.add(key(m))
        if coordinates:
            for axis in ('x','y'):
                if type(m.get(axis)) not in (int,float) or not math.isfinite(m[axis]) or not 0<=m[axis]<=1:
                    raise ValueError('marker x/y must be finite normalized0..1 coordinates')
    return marks


def record_digest(record):return digest(canonical({k:v for k,v in record.items() if k!='digest'}))


class FloorplanLibrary:
    def __init__(self,service):self.service=service

    def path(self,ident,ext='json'):
        if type(ident) is not str or not re.fullmatch('[0-9a-f]{32}',ident):raise ValueError('invalid floorplan ID')
        return self.service.state_dir/f'floorplan-library-{ident}.{ext}'

    def get(self,ident):
        raw=self.path(ident).read_bytes()
        if len(raw)>200_000:raise ValueError('floorplan record too large')
        d=json.loads(raw)
        if d.get('format')!='dali-floorplan-library-v1' or d.get('floorplan_id')!=ident or d.get('digest')!=record_digest(d):
            raise ValueError('floorplan record checksum mismatch')
        validate_marks(d['marks']);validate_marks(d['removed_marks'],False);validate_marks(d['edited_marks'],False)
        if inspect_library_png(self.path(ident,'png').read_bytes())!=d['image']:raise ValueError('floorplan image checksum mismatch')
        return d

    def list(self):
        rows=[]
        for p in sorted(self.service.state_dir.glob('floorplan-library-*.json')):
            ident=p.stem.removeprefix('floorplan-library-')
            try:
                d=self.get(ident);rows.append({k:d[k] for k in ('floorplan_id','name','created_at','parent_id','mark_count')})
            except (ValueError,OSError,KeyError) as exc:rows.append(dict(floorplan_id=ident,error=str(exc)))
        return dict(floorplans=rows,storage=str(self.service.state_dir),native_multi_image_support=False,device_commands_sent=0)

    def _save(self,name,data,marks,source,parent=None,removed=None,edited=None):
        if type(name) is not str or not 1<=len(name.strip())<=80:raise ValueError('name requires1..80 characters')
        validate_marks(marks);removed=removed or [];validate_marks(removed,False)
        if edited is None:edited=[dict(ch=m['ch'],addr=m['addr']) for m in marks]
        validate_marks(edited,False)
        ident=uuid.uuid4().hex
        d=dict(format='dali-floorplan-library-v1',floorplan_id=ident,name=name.strip(),created_at=time.time(),parent_id=parent,
               image=inspect_library_png(data),marks=copy.deepcopy(marks),removed_marks=copy.deepcopy(removed),edited_marks=copy.deepcopy(edited),mark_count=len(marks),source=source,
               physical_mapping_verified=False,native_application_written=False,device_commands_sent=0)
        d['digest']=record_digest(d)
        NativeFileController._write_new(self.path(ident,'png'),data)
        NativeFileController._write_new(self.path(ident),canonical(d))
        return d

    def import_image(self,image_path,name,marks=None):
        path=Path(image_path)
        if not path.is_absolute():raise ValueError('absolute local image path required')
        _no_links(path)
        with path.open('rb') as f:raw=f.read(LIBRARY_IMAGE_LIMIT+1)
        if len(raw)>LIBRARY_IMAGE_LIMIT:raise ValueError('source image must be at most40MB')
        # Decode only supported raster formats; bounds are checked before load.
        from PIL import Image,ImageOps
        with Image.open(io.BytesIO(raw),formats=['PNG','JPEG']) as im:
            if im.width*im.height>LIBRARY_PIXEL_LIMIT or max(im.size)>LIBRARY_SIDE_LIMIT:raise ValueError('image limit40 megapixels /16384 pixels per side; resize the source explicitly')
            if getattr(im,'n_frames',1)!=1:raise ValueError('animated/multi-frame source is unsupported')
            normalized=ImageOps.exif_transpose(im).convert('RGBA')
            out=io.BytesIO();normalized.save(out,format='PNG',optimize=True)
        return self._save(name,out.getvalue(),marks or [],dict(kind='local_image',path=str(path),sha256=digest(raw),exif_orientation_applied=True))

    def from_native(self,name):
        ctl=NativeFloorplanFileController(self.service);path=ctl._target()
        with ctl._locked(path):
            before,document=ctl._read(path);asset,data=native_asset_snapshot(ctl,path,document)
        if data is None:raise ValueError('configured native file has no readable background image')
        # Disk snapshot only; do not suggest unsaved in-memory edits were captured.
        return self._save(name,data,document['floorPlan']['marks'],dict(kind='native_disk_snapshot',cache_path=str(path),cache_sha256=digest(before),
            native_floorplan=copy.deepcopy(document['floorPlan']),asset=asset,in_memory_changes_included=False),edited=[])

    def set_marks(self,ident,marks,remove=None):
        d=self.get(ident);validate_marks(marks);remove=remove or [];validate_marks(remove,False)
        if {key(x) for x in marks}&{key(x) for x in remove}:raise ValueError('same marker cannot be updated and removed in one edit')
        merged={key(x):copy.deepcopy(x) for x in d['marks']}
        removed={key(x):dict(ch=x['ch'],addr=x['addr']) for x in d['removed_marks']}
        edited={key(x):dict(ch=x['ch'],addr=x['addr']) for x in d['edited_marks']}
        for x in remove:merged.pop(key(x),None);removed[key(x)]=dict(ch=x['ch'],addr=x['addr']);edited.pop(key(x),None)
        for x in marks:
            merged[key(x)]={**merged.get(key(x),{}),**x};removed.pop(key(x),None);edited[key(x)]=dict(ch=x['ch'],addr=x['addr'])
        return self._save(d['name'],self.path(ident,'png').read_bytes(),list(merged.values()),d['source'],ident,list(removed.values()),list(edited.values()))

    def export(self,ident,output_path,annotated=True):
        d=self.get(ident);path=Path(output_path)
        if not path.is_absolute() or path.suffix.lower()!='.png':raise ValueError('absolute .png output path required')
        _no_links(path)
        if path.exists():raise FileExistsError('export never overwrites an existing file')
        raw=self.path(ident,'png').read_bytes()
        if annotated:
            from PIL import Image,ImageDraw,ImageFont
            im=Image.open(io.BytesIO(raw)).convert('RGBA');draw=ImageDraw.Draw(im)
            radius=max(4,min(im.size)//75);font=ImageFont.load_default(size=max(12,radius*2))
            for m in d['marks']:
                x=round(m['x']*(im.width-1));y=round(m['y']*(im.height-1))
                label=('A' if m['ch']==1 else 'B')+str(m['addr'])
                draw.ellipse((x-radius,y-radius,x+radius,y+radius),fill='#ffd438',outline='#252525',width=2)
                box=draw.textbbox((0,0),label,font=font);w=box[2]-box[0]+6;h=box[3]-box[1]+6
                tx=max(0,min(im.width-w,x+radius+2));ty=max(0,min(im.height-h,y-h//2))
                draw.rectangle((tx,ty,tx+w,ty+h),fill='#252525')
                draw.text((tx+3-box[0],ty+3-box[1]),label,font=font,fill='#ffffff')
            out=io.BytesIO();im.save(out,format='PNG');raw=out.getvalue()
        NativeFileController._write_new(path,raw)
        return dict(floorplan_id=ident,output_path=str(path),sha256=digest(raw),bytes=len(raw),annotated=annotated,
            mark_count=len(d['marks']) if annotated else 0,rendering='toolkit marker rendering; not a native ConfigMaster screenshot' if annotated else 'original normalized background',
            physical_mapping_verified=False,device_commands_sent=0)
