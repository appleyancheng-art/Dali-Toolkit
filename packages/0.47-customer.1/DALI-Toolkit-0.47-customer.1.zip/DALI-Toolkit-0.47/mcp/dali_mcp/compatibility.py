"""One firmware policy for discovery, configured sessions and wire dispatch.

Support is capability-scoped, never inferred from an arbitrary config string.
New firmware stays read-only until a reviewed profile is shipped.
"""
READ_COMMANDS=frozenset((0xfe01,0xfe30,0xf016,0xf01a,0xf01d,0xf01f,
    0xf021,0xf023,0xf025,0xf027,0xf029,0xf032,0xf035,0xf03a,0xf043,0xf047))
COMMAND_FEATURE={
    **{c:'live' for c in (0xf010,0xf011,0xf012,0xf013,0xf02b,0xf02c)},
    0xf039:'scenes',0xf014:'groups',0xf015:'groups',
    **{c:'parameters' for c in (0xf018,0xf019,0xf01c,0xf01e,0xf020,0xf022,0xf024,0xf026,0xf028)},
    0xf001:'addressing',0xf002:'addressing',0xf003:'channel_reset',
}
PROFILES={
    '1.6.9':dict(features=['live','scenes','groups','parameters','addressing'],evidence='0.45 release validation; per-tool limits still apply'),
    '1.6.11':dict(features=['live','scenes','groups','parameters','addressing','full_readdress','channel_reset'],evidence='0.47: A10 DT8 move/remove/incremental allocation/vacant-address swap/full readdress/channel reset field acceptance. Existing 0.46 live/scene/group/parameter coverage retained. Full64 swap simulated only; reset receipt and supported-value snapshot do not prove all manufacturer defaults. See docs/VALIDATION-0.47.md.'),
}


def firmware_policy(firmware):
    profile=PROFILES.get(firmware)
    return dict(firmware=firmware,profile='supported' if profile else 'unvalidated_read_only',
        read_allowed=True,control_allowed=bool(profile),
        control_features=list(profile['features']) if profile else [],
        evidence=profile['evidence'] if profile else 'Identity and known read commands only; no lighting/storage/address commands',
        all_functions_validated=False,expected_version_is_not_validation=True)


def require_command(firmware,command,payload):
    if command in READ_COMMANDS or (command==0xf001 and len(payload)==3 and payload[1:]==b'\0\0'):
        return
    category=COMMAND_FEATURE.get(command)
    if command==0xf002 and (len(payload)!=4 or payload[0] not in (1,2) or payload[1]!=1
            or payload[2]>63 or payload[3] not in (*range(64),255) or payload[2]==payload[3]):
        raise PermissionError('invalid address edit scope; no command sent')
    if command==0xf001:
        if len(payload)!=3 or payload[0] not in (1,2) or payload[2]!=0 or payload[1] not in (1,2):
            raise PermissionError('unimplemented allocation mode; no command sent')
        if payload[1]==1:category='full_readdress'
    if command==0xf003 and (len(payload)!=3 or payload[0] not in (1,2) or payload[1:]!=b'\0\xff'):
        raise PermissionError('only observed channel reset scope is implemented; no command sent')
    policy=firmware_policy(firmware)
    if category not in policy['control_features']:
        raise PermissionError(f'Firmware {firmware}: {category or hex(command)} control is not supported; '
                              'no command sent. Read-only connection remains available; do not edit expected_firmware to bypass compatibility.')
