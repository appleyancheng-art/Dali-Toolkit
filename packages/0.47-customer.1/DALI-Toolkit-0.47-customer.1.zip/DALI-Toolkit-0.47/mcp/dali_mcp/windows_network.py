"""Windows IPv4 NIC inventory via IP Helper, no PATH or subprocess dependency.

Structures: Microsoft IP_ADAPTER_ADDRESSES_LH / UNICAST_ADDRESS_LH.
Only prefixes present in the returned Length are read. Windows Vista+.
"""
import ctypes as C
import os
import socket


def adapter_rows():
    if os.name!='nt':raise RuntimeError('Windows network inventory requires Windows; no discovery packets sent')
    U=C.c_uint32;P=C.c_void_p
    class SocketAddress(C.Structure):_fields_=[('pointer',P),('length',C.c_int)]
    class Unicast(C.Structure):pass
    Unicast._fields_=[('Length',U),('Flags',U),('Next',C.POINTER(Unicast)),
        ('Address',SocketAddress),('PrefixOrigin',C.c_int),('SuffixOrigin',C.c_int),
        ('DadState',C.c_int),('ValidLifetime',U),('PreferredLifetime',U),('LeaseLifetime',U),('PrefixLength',C.c_ubyte)]
    class Adapter(C.Structure):pass
    Adapter._fields_=[('Length',U),('IfIndex',U),('Next',C.POINTER(Adapter)),('AdapterName',P),
        ('FirstUnicast',C.POINTER(Unicast)),('Anycast',P),('Multicast',P),('DnsServer',P),
        ('DnsSuffix',C.c_wchar_p),('Description',C.c_wchar_p),('FriendlyName',C.c_wchar_p),
        ('PhysicalAddress',C.c_ubyte*8),('PhysicalAddressLength',U),('Flags',U),
        ('Mtu',U),('IfType',U),('OperStatus',C.c_int)]
    api=C.WinDLL('iphlpapi',use_last_error=True).GetAdaptersAddresses
    api.argtypes=[U,U,P,C.POINTER(Adapter),C.POINTER(U)];api.restype=U
    size=U(15000)
    for _ in range(3):
        if not 0<size.value<=4_000_000:raise RuntimeError('Invalid network inventory buffer size')
        buf=C.create_string_buffer(size.value);head=C.cast(buf,C.POINTER(Adapter))
        status=api(socket.AF_INET,0x0e,None,head,C.byref(size))
        if status==111:continue
        if status==232:return []
        if status:raise OSError(status,'GetAdaptersAddresses failed; no discovery packets sent')
        rows=[];seen=set();item=head
        while item:
            location=C.addressof(item.contents)
            if location in seen:raise RuntimeError('Cyclic adapter inventory')
            seen.add(location);a=item.contents
            if a.Length < Adapter.OperStatus.offset+C.sizeof(C.c_int):raise RuntimeError('Unsupported adapter structure')
            if a.OperStatus==1 and a.IfType!=24:
                address=a.FirstUnicast;addresses=set()
                while address:
                    loc=C.addressof(address.contents)
                    if loc in addresses:raise RuntimeError('Cyclic unicast inventory')
                    addresses.add(loc);u=address.contents
                    if (u.Length>=Unicast.PrefixLength.offset+1 and u.DadState==4
                            and u.Address.pointer and u.Address.length>=16):
                        raw=C.string_at(u.Address.pointer,8)
                        if int.from_bytes(raw[:2],'little')==socket.AF_INET:
                            rows.append(dict(IPAddress=socket.inet_ntoa(raw[4:8]),PrefixLength=int(u.PrefixLength),
                                InterfaceIndex=int(a.IfIndex),InterfaceAlias=a.FriendlyName or a.Description or str(a.IfIndex)))
                    address=u.Next
            item=a.Next
        return rows
    raise RuntimeError('Network interfaces changed repeatedly; retry inventory after network stabilizes')
