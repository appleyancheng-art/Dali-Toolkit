"""Resumable, timestamped read-only capture; each resume creates a new revision."""
import copy
import hashlib
import json
import time
import uuid
from .read_session import ReadSession
from .protocol import Gateway


def checkpoint_hash(record):
    data={k:v for k,v in record.items() if k not in ('digest','checkpoint_sha256')}
    return hashlib.sha256(json.dumps(data,sort_keys=True,ensure_ascii=False,allow_nan=False,separators=(',',':')).encode()).hexdigest()


def capture(service,name,channel,addresses,scenes,source_id=None):
    from .projects import scope_values,identity,validate_document,validate_parameter,digest
    scope_values(channel,addresses,scenes)
    if type(name) is not str or not 1<=len(name.strip())<=80:raise ValueError('project name requires1..80 characters')
    scope=dict(channel=channel,addresses=sorted(addresses),scenes=sorted(scenes))
    with service.lock:
        rows=[];source=None
        if source_id:
            source=service.get_project(source_id)
            if source.get('state')!='stopped_partial':raise ValueError('Resume requires a stopped_partial checkpoint; never replay an active/completed capture')
            if source.get('checkpoint_sha256')!=checkpoint_hash(source):raise ValueError('Checkpoint missing/corrupt; legacy partial records require a fresh capture')
            if source['scope']!=scope:raise ValueError('Resume scope must remain exactly the captured scope')
            if time.time()-source['started_at']>86400:raise ValueError('Checkpoint older than24h; start a fresh capture')
            rows=copy.deepcopy(source['rows'])
            if len({r['address'] for r in rows})!=len(rows):raise ValueError('duplicate checkpoint row')
            for row in rows:
                if row.get('channel')!=channel or row.get('address') not in addresses:raise ValueError('Invalid checkpoint row scope')
                if row['parameters']:
                    typ=row['parameters']['light_type']['value']['code']
                    for field,value in row['parameters'].items():
                        if field not in Gateway.PARAMETER_FIELDS:raise ValueError('Invalid checkpoint field')
                        validate_parameter(field,value,typ)
                if len({s['scene'] for s in row['scenes']})!=len(row['scenes']):raise ValueError('duplicate checkpoint scene')
                for s in row['scenes']:
                    if s.get('channel')!=channel or s.get('address')!=row['address'] or s.get('scene') not in scenes:
                        raise ValueError('invalid checkpoint scene scope')
                    from .service import SceneChange
                    SceneChange.model_validate({k:s[k] for k in SceneChange.model_fields})
                    if s['kelvin_raw']!=65535 and not 1000<=s['kelvin_raw']<=10000:raise ValueError('invalid checkpoint scene color')
        ident=uuid.uuid4().hex;session=ReadSession(service)
        report=dict(format='dali-toolkit-project',schema_version=1,project_id=ident,name=name.strip(),scope=scope,
            state='reading',started_at=source['started_at'] if source else time.time(),rows=rows,origin='resumed_bus_capture' if source else 'fresh_bus_capture',
            atomic_snapshot=False,device_writes=False,read_retries=[],
            not_included=['live_output','physical_ct_limits','extended_fade','device_version','PC_labels','PC_project_format','gateway_settings','physical_layouts'])
        if source:report.update(resumed_from=source_id,resume_started_at=time.time(),source_checkpoint_sha256=source['checkpoint_sha256'],
            reused_fields=sum(len(r['parameters'])+len(r['scenes']) for r in rows),sampling_note='Reused fields retain their original timestamps; resumed capture is not simultaneous and does not revalidate previously captured device values')
        def save():
            report['read_retries']=list(session.retries)
            report['checkpoint_sha256']=checkpoint_hash(report)
            if report['state']=='completed':report['digest']=digest(report)
            service._save('project',report,ident)
        try:
            save();info=session.connect();report['gateway']=info
            if source and identity(info)!=identity(source['gateway']):raise ValueError('Checkpoint belongs to a different gateway/IP/firmware; fresh capture required')
            for address in sorted(addresses):
                row=next((r for r in rows if r['address']==address),None)
                if row is None:row=dict(channel=channel,address=address,parameters={},scenes=[]);rows.append(row)
                typ=row['parameters'].get('light_type',{}).get('value',{}).get('code')
                for field in Gateway.PARAMETER_FIELDS:
                    if field in row['parameters']:continue
                    pending=dict(address=address,kind='parameter',field=field);report['pending']=pending;save()
                    value=session.read('read_lamp_parameter',channel,address,field,typ,context=pending)
                    value['captured_at']=time.time();row['parameters'][field]=value
                    if field=='light_type':typ=value['value']['code']
                    save()
                for scene in sorted(scenes):
                    if any(s['scene']==scene for s in row['scenes']):continue
                    pending=dict(address=address,kind='scene',scene=scene);report['pending']=pending;save()
                    value=session.read('read_scene',channel,address,scene,typ,context=pending)
                    value['captured_at']=time.time();row['scenes'].append(value);save()
                report.pop('pending',None)
            report.update(state='completed',completed_at=time.time());save();validate_document(report)
        except (Exception,KeyboardInterrupt) as exc:
            report.pop('digest',None)
            report.update(state='stopped_partial',error=str(exc) or type(exc).__name__,stopped_at=time.time(),
                          next_action='Inspect pending/error; dali_resume_project_capture creates a new revision and continues only missing read fields. No device writes.')
        finally:session.close();save()
        return report
