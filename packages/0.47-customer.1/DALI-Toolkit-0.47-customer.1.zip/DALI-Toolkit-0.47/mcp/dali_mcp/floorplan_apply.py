"""Lightweight drafts use the same guarded, journaled native-file transaction."""
import copy
import json
import uuid
from .floorplan_library import FloorplanLibrary,record_digest,validate_marks,key,inspect_library_png,native_asset_snapshot,LIBRARY_IMAGE_LIMIT
from .native_floorplan_file import NativeFloorplanFileController,field,same
from .native_file import digest,parse,serialize
from .native_cache import canonical,inspect_configmaster_cache
from .native_floorplan import inspect_native_floorplan
from .project_floorplan import inspect_png


class FloorplanApply(NativeFloorplanFileController):
    def _asset_snapshot(self,path,document):return native_asset_snapshot(self,path,document)

    def _record_path(self,kind,ident,suffix='json'):
        # Parent validates ID before creating a path; independent record namespace.
        return super()._record_path(kind,ident,suffix).with_name(f'native-library-{kind}-{ident}.{suffix}')

    @staticmethod
    def _desired(draft,document,ident,mode):
        if mode not in ('merge','replace'):raise ValueError('mode must be merge or replace')
        out=copy.deepcopy(document);layout=copy.deepcopy(out.get('floorPlan',{}))
        marks={key(m):copy.deepcopy(m) for m in layout.get('marks',[])} if mode=='merge' else {}
        for m in draft['removed_marks']:marks.pop(key(m),None)
        selected={key(m) for m in draft['edited_marks']}
        for m in draft['marks']:
            if mode=='replace' or key(m) in selected:marks[key(m)]={**marks.get(key(m),{}),**m}
        layout.update(image=f'dali-toolkit-{ident}.png',marks=list(marks.values()))
        out['floorPlan']=layout;inspect_native_floorplan(out)
        return out

    def prepare(self,floorplan_id,mode='merge'):
        lib=FloorplanLibrary(self.service);draft=lib.get(floorplan_id);path=self._target()
        with self._locked(path):
            before,document=self._read(path);asset,old_image=self._asset_snapshot(path,document)
            if mode=='merge' and (old_image is None or digest(old_image)!=draft['image']['sha256']):
                raise ValueError('merge requires the same background image; import the native disk image first or explicitly choose replace. Different-image coordinates cannot be merged safely')
            ident=uuid.uuid4().hex;target=self._desired(draft,document,ident,mode)
            after=serialize(target,before);parse(after)
            image_path=self._asset_path(path,target['floorPlan']['image'])
            if image_path.exists():raise FileExistsError('new background path exists')
            self._write_new(self._record_path('draft',ident,'bin'),canonical(draft))
            self._write_new(self._record_path('image',ident,'bin'),lib.path(floorplan_id,'png').read_bytes())
            if old_image is not None:self._write_new(self._record_path('original-image',ident,'bin'),old_image)
            return self._save_plan(dict(plan_id=ident,operation='floorplan',file_path=str(path),source_floorplan_id=floorplan_id,
                source_digest=draft['digest'],mode=mode,before_floorplan=field(document),after_floorplan=field(target),original_asset=asset,
                new_image_path=str(image_path),target_mark_count=len(target['floorPlan']['marks']),local_floorplan_replaced=mode=='replace',
                existing_images_preserved=True,generated_images_retained_after_undo=True,
                application_must_be_closed_at_apply=True,native_multi_image_support=False),before,after)

    def _load(self,ident):
        p=json.loads(self._record_path('plan',ident).read_bytes())
        if p.get('plan_id')!=ident or p.get('digest')!=self._plan_digest(p) or p.get('format')!='native-floorplan-file-v1':raise ValueError('floorplan plan checksum mismatch')
        if p['file_path']!=str(self._target()):raise ValueError('configured native cache path changed')
        before=self._record_path('before',ident,'bin').read_bytes();after=self._record_path('after',ident,'bin').read_bytes()
        if digest(before)!=p['before_sha256'] or digest(after)!=p['after_sha256']:raise ValueError('floorplan backup checksum mismatch')
        first,last=parse(before),parse(after)
        for d in (first,last):self.service._check_native_identity(inspect_configmaster_cache(d))
        if not same(field(first),p['before_floorplan']) or not same(field(last),p['after_floorplan']):raise ValueError('review differs from backups')
        if p.get('device_commands_sent')!=0 or p.get('generated_images_retained_after_undo') is not True:raise ValueError('invalid plan review')
        if p['operation']=='floorplan':
            raw=self._record_path('draft',ident,'bin').read_bytes()
            if len(raw)>200_000:raise ValueError('draft too large')
            draft=json.loads(raw)
            if draft.get('digest')!=record_digest(draft) or draft.get('digest')!=p['source_digest'] or draft.get('floorplan_id')!=p['source_floorplan_id']:raise ValueError('draft backup checksum mismatch')
            validate_marks(draft['marks']);validate_marks(draft['removed_marks'],False)
            if inspect_library_png(self._project_image(p))!=draft['image']:raise ValueError('draft image checksum mismatch')
            expected=self._desired(draft,first,ident,p['mode'])
            if serialize(expected,before)!=after:raise ValueError('plan changed fields outside scoped floorplan edit')
            if p['target_mark_count']!=len(expected['floorPlan']['marks']) or p['new_image_path']!=str(self._asset_path(self._target(),expected['floorPlan']['image'])):raise ValueError('invalid image/marker review')
            if p.get('existing_images_preserved') is not True or p['local_floorplan_replaced']!=(p['mode']=='replace'):raise ValueError('invalid replacement review')
            asset=p['original_asset'];summary=inspect_native_floorplan(first)
            if not summary['present']:
                if asset!=dict(state='no_floorplan'):raise ValueError('invalid original asset')
            elif asset.get('filename')!=summary['image_reference'] or asset.get('state') not in ('present','missing'):raise ValueError('invalid original asset')
            if asset['state']=='present':
                original=self._record_path('original-image',ident,'bin').read_bytes()
                if inspect_library_png(original)!=asset['metadata']:raise ValueError('original image backup mismatch')
            if p['mode']=='merge' and (asset['state']!='present' or asset['metadata']['sha256']!=draft['image']['sha256']):raise ValueError('merge image differs from original')
        elif p['operation']=='restore':
            head=json.loads(self._record_path('plan',p['source_plan_id']).read_bytes())
            if head.get('operation')!='floorplan':raise ValueError('undo source must be original floorplan edit')
            source,old,new=self._load(p['source_plan_id']);self._require_intent(source)
            restored=self._restore_document(first,source,old,new)
            expected=old if before==new else (before if same(restored,first) else serialize(restored,before))
            if after!=expected or p['source_digest']!=source['digest']:raise ValueError('undo differs from original scoped edit')
        else:raise ValueError('unsupported floorplan operation')
        return p,before,after

    def _project_image(self,plan):return self._record_path('image',plan['plan_id'],'bin').read_bytes()

    def _check_source_current(self,plan):
        draft=FloorplanLibrary(self.service).get(plan['source_floorplan_id'])
        if draft['digest']!=plan['source_digest']:raise ValueError('source floorplan changed since preparation')

    def _check_dependencies(self,plan,path):
        if 'plan_id' in plan:self._check_gates(plan)
        source=plan
        if plan['operation']=='restore':source,_,_=self._load(plan['source_plan_id'])
        else:self._check_source_current(plan)
        old=parse(self._record_path('before',source['plan_id'],'bin').read_bytes())
        self._check_old_asset(path,old,source['original_asset'])
        target=self._asset_path(path,source['after_floorplan']['value']['image'])
        with target.open('rb') as f:actual=f.read(LIBRARY_IMAGE_LIMIT+1)
        if actual!=self._project_image(source):raise ValueError('generated background changed or incomplete')
