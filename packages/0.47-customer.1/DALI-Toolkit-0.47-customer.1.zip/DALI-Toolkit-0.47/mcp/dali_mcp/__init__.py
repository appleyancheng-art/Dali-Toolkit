"""DALI Toolkit."""
__version__ = "0.47"
