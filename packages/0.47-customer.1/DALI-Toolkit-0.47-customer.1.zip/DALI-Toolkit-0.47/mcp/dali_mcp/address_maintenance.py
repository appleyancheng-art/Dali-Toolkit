"""Journalled channel maintenance, with read-only preparation and one-shot jobs.

No automatic replay, undo, physical identity inference, or label migration.
Uses the existing allocation worker/persistence machinery and serial bus lock.
"""
import copy
import math
import time
import uuid
from .address_allocation import AddressAllocationController, CancelledBeforeWrite, fingerprint
from .address_moves import address_set
from .projects import digest
from .compatibility import require_command


def scope(operation, channel, first_address=None, second_address=None,
          expected_total=None, allow_temporary_unaddressed=False):
    if operation not in ('swap','readdress','factory_reset'):
        raise ValueError('operation must be swap, readdress or factory_reset')
    if type(channel) is not int or channel not in (1,2):raise ValueError('channel1/2 required')
    if type(allow_temporary_unaddressed) is not bool:raise ValueError('boolean required')
    if operation=='swap':
        if any(type(a) is not int or not 0<=a<=63 for a in (first_address,second_address)):
            raise ValueError('two explicit short addresses0..63 required')
        if first_address==second_address:raise ValueError('two different addresses required')
        if allow_temporary_unaddressed:
            if type(expected_total) is not int or expected_total!=64:
                raise ValueError('full-channel swap requires explicitly known64 connected gear, all addressed')
        elif expected_total is not None:raise ValueError('expected_total only applies to full-channel swap')
    else:
        if first_address is not None or second_address is not None or allow_temporary_unaddressed:
            raise ValueError('channel-wide operation must not contain single-address arguments')
        if operation=='readdress':
            if type(expected_total) is not int or not 1<=expected_total<=64:
                raise ValueError('expected_total1..64 required; assertion, not a device-side limit')
        elif expected_total is not None:raise ValueError('reset has no assumed post-reset address count')
    return dict(operation=operation,channel=channel,first_address=first_address,second_address=second_address,
                expected_total=expected_total,allow_temporary_unaddressed=allow_temporary_unaddressed)


def steps_for(target, addresses):
    if target['operation']!='swap':return [dict(kind=target['operation'])]
    a,b=target['first_address'],target['second_address']
    if a not in addresses or b not in addresses:raise ValueError('both swap addresses must exist')
    vacant=sorted(set(range(64))-set(addresses))
    if vacant:
        t=vacant[0]
        return [dict(kind='move',source=a,destination=t),dict(kind='move',source=b,destination=a),
                dict(kind='move',source=t,destination=b)]
    if not target['allow_temporary_unaddressed']:
        raise ValueError('no vacant short address; no implicit deletion. Full-channel strategy requires explicitly known64 gear and permission to temporarily unaddress one')
    return [dict(kind='remove',source=a,destination=255),dict(kind='move',source=b,destination=a),
            dict(kind='allocate_one',destination=b)]


class AddressMaintenanceController(AddressAllocationController):
    def _path(self,kind,ident):
        self.base._id(ident)
        return self.service.state_dir/f'address-maintenance-{kind}-{ident}.json'

    def _request(self,ident):
        q=self._read('request',ident)
        if q.get('operation_id')!=ident or q.get('digest')!=digest(q) or q['scope']!=scope(**q['scope']):
            raise ValueError('invalid maintenance request')
        return q

    def _plan(self,ident):
        q=self._request(ident);p=self._read('plan',ident)
        if (p.get('operation_id')!=ident or p.get('digest')!=digest(p)
                or p['request_digest']!=q['digest'] or p['scope']!=q['scope']):
            raise ValueError('maintenance plan checksum/binding mismatch')
        addresses=address_set(p['before_addresses'])
        if [r['address'] for r in p['originals']]!=addresses:raise ValueError('incomplete original coverage')
        for r in p['originals']:
            if r['channel']!=p['scope']['channel']:raise ValueError('snapshot channel mismatch')
            fingerprint(r)
        if p['steps']!=steps_for(p['scope'],addresses):raise ValueError('maintenance steps changed')
        for key in ('created_at','expires_at'):
            if type(p[key]) not in (int,float) or not math.isfinite(p[key]):raise ValueError('invalid plan time')
        if p['expires_at']!=p['created_at']+1800:raise ValueError('invalid plan lifetime')
        for key in ('physical_identity_verified','automatic_undo','host_mappings_migrated'):
            if p.get(key) is not False:raise ValueError('invalid maintenance guarantee')
        return p

    @staticmethod
    def _confirmation(p):
        return f"{p['scope']['operation'].upper()} CHANNEL {p['scope']['channel']} {p['operation_id']} {p['digest']}"

    def start_review(self,operation,channel,first_address=None,second_address=None,
                     expected_total=None,allow_temporary_unaddressed=False):
        target=scope(operation,channel,first_address,second_address,expected_total,allow_temporary_unaddressed)
        with self.runtime_lock:
            if self.active is not None:raise RuntimeError('maintenance task already active')
            ident=uuid.uuid4().hex;q=dict(operation_id=ident,scope=target,created_at=time.time())
            q['digest']=digest(q);self._save('request',ident,q,exclusive=True)
            return self._launch(ident,'review',lambda cancel:self.review(ident,cancel))

    def review(self,ident,cancelled=lambda:False):
        q=self._request(ident)
        run=dict(operation_id=ident,state='reviewing',started_at=time.time(),device_writes=False)
        with self.base._locked():
            try:
                self._save('review',ident,run)
                if cancelled():raise CancelledBeforeWrite()
                self.base.process_guard();ch=q['scope']['channel']
                info,scan=self.base._scan(ch);run['scan']=scan
                steps=steps_for(q['scope'],scan['addresses'])
                run['duplicates']=self.base._duplicates(ch,info)
                rows=self._rows(ident,'review',run,'originals',ch,scan['addresses'],info,cancelled)
                _,run['final_scan']=self.base._scan(ch,info)
                if run['final_scan']['addresses']!=scan['addresses']:raise ValueError('occupancy changed during review')
                if cancelled():raise CancelledBeforeWrite()
                self.base.process_guard();now=time.time()
                p=dict(operation_id=ident,request_digest=q['digest'],scope=q['scope'],gateway=info,
                       before_addresses=scan['addresses'],originals=rows,steps=steps,created_at=now,expires_at=now+1800,
                       physical_identity_verified=False,automatic_undo=False,host_mappings_migrated=False,
                       warning='Channel readdress/reset can lose physical mapping and stored data. Backup values are not hardware IDs. Reset is the native channel reset, not a gateway/network reset.')
                p['digest']=digest(p);self._save('plan',ident,p,exclusive=True)
                run.update(state='reviewed',plan_digest=p['digest'])
            except CancelledBeforeWrite:run['state']='cancelled_before_write'
            except (Exception,KeyboardInterrupt) as exc:run.update(state='review_failed',error=str(exc) or type(exc).__name__)
            finally:
                run['finished_at']=time.time();self._save('review',ident,run)
        return run

    def _gate(self,p):
        cfg=self.service.config
        if cfg.get('enable_address_maintenance') is not True:raise PermissionError('address maintenance write gate required')
        if cfg.get('allowed_address_maintenance_digest')!=p['digest']:raise PermissionError('exact maintenance plan digest required')
        allowed=cfg.get('allowed_address_maintenance_operations')
        exact=dict(operation=p['scope']['operation'],channel=p['scope']['channel'])
        if not isinstance(allowed,list) or any(type(v) is not dict or set(v)!=set(exact)
                or type(v['channel']) is not int or v['channel'] not in (1,2)
                or v['operation'] not in ('swap','readdress','factory_reset') for v in allowed) or exact not in allowed:
            raise PermissionError('exact operation and channel scope required')
        # Reject unsupported firmware before a claim or durable device intent;
        # the protocol checks again against the freshly discovered firmware.
        ch=p['scope']['channel']
        for step in p['steps']:
            if step['kind'] in ('move','remove'):
                command,payload=0xf002,bytes([ch,1,step['source'],step['destination']])
            elif step['kind'] in ('readdress','allocate_one'):
                command,payload=0xf001,bytes([ch,1 if step['kind']=='readdress' else 2,0])
            else:command,payload=0xf003,bytes([ch,0,255])
            require_command(p['gateway']['dali_firmware'],command,payload)

    def _dispatch(self,ident,p,run,step):
        self._gate(p);self.base.process_guard()
        if time.time()>p['expires_at']:raise ValueError('maintenance plan expired before next step')
        g,_=self.base._open(p['gateway'])
        record=dict(index=len(run['steps']),step=step,write_intent=True,started_at=time.time())
        try:
            run['steps'].append(record);run.update(write_intent=True,state='dispatching')
            self._save('execution',ident,run)
            ch=p['scope']['channel'];kind=step['kind']
            if kind in ('move','remove'):record['receipt']=g.change_short_address(ch,step['source'],step['destination'])
            elif kind=='allocate_one':record['receipt']=g.allocate_missing_addresses(ch)
            elif kind=='readdress':record['receipt']=g.readdress_channel(ch)
            else:record['receipt']=g.reset_channel(ch)
        except (Exception,KeyboardInterrupt) as exc:
            record['dispatch_error']=str(exc) or type(exc).__name__
        finally:
            record['protocol_replies']=list(g.recent_packets);g.close()
            record['finished_at']=time.time();self._record('execution',ident,run,True)
        return record

    def execute(self,ident,confirmation,cancelled=lambda:False):
        with self.base._locked():
            p=self._plan(ident);self._review_complete(ident,p);self._gate(p)
            if confirmation!=self._confirmation(p) or time.time()>p['expires_at']:raise ValueError('invalid confirmation or expired plan')
            self.base.process_guard()
            self._save('claim',ident,dict(operation_id=ident,plan_digest=p['digest'],claimed_at=time.time()),exclusive=True)
            run=dict(operation_id=ident,plan_digest=p['digest'],state='preflight',started_at=time.time(),write_intent=False,
                     automatic_undo=False,physical_identity_verified=False,steps=[])
            try:
                self._save('execution',ident,run);ch=p['scope']['channel'];op=p['scope']['operation']
                if cancelled():raise CancelledBeforeWrite()
                _,run['before_scan']=self.base._scan(ch,p['gateway'])
                if run['before_scan']['addresses']!=p['before_addresses']:raise ValueError('occupancy changed since review')
                run['duplicates']=self.base._duplicates(ch,p['gateway'])
                original={r['address']:fingerprint(r) for r in p['originals']}
                rows=self._rows(ident,'execution',run,'preflight_rows',ch,p['before_addresses'],p['gateway'],cancelled)
                if {r['address']:fingerprint(r) for r in rows}!=original:raise ValueError('lamp values changed since review')
                _,run['dispatch_scan']=self.base._scan(ch,p['gateway'])
                if run['dispatch_scan']['addresses']!=p['before_addresses']:raise ValueError('occupancy changed during preflight')
                if cancelled():raise CancelledBeforeWrite()
                run['capability_invalidation_id']=self.service.invalidate_capabilities(ch,list(range(64)),f'maintenance {ident}')
                expected=copy.deepcopy(original);parked=None
                for step in p['steps']:
                    if cancelled():
                        run['state']='stopped_between_steps' if run['write_intent'] else 'cancelled_before_write';break
                    record=self._dispatch(ident,p,run,step)
                    # Never replay a lost command. Still independently observe the bus.
                    _,record['after_scan']=self.base._scan(ch,p['gateway'])
                    after=record['after_scan']['addresses']
                    record['duplicates']=self.base._duplicates(ch,p['gateway'])
                    if op=='swap':
                        if step['kind']=='remove':parked=expected.pop(step['source'])
                        elif step['kind']=='move':expected[step['destination']]=expected.pop(step['source'])
                        else:expected[step['destination']]=parked
                        if sorted(expected)!=after:
                            run['state']='stopped_address_mismatch';break
                        # Check the moved fixture at each intermediate step, then all
                        # original fixtures once at the end. Re-reading every unchanged
                        # fixture after every move wastes bus time and can expire a
                        # full-channel plan. Occupancy is checked after every command.
                        checked=after if step is p['steps'][-1] else ([] if step['kind']=='remove' else [step['destination']])
                        rows=self._rows(ident,'execution',run,'after_rows',ch,checked,p['gateway'],tolerate_log_failure=True)
                        record['readback_addresses']=checked
                        record['supported_values_match']={r['address']:fingerprint(r) for r in rows}=={a:expected[a] for a in checked}
                        if not record['supported_values_match']:
                            run['state']='stopped_lamp_mismatch';break
                    else:
                        rows=self._rows(ident,'execution',run,'after_rows',ch,after,p['gateway'],tolerate_log_failure=True)
                        run['after_addresses']=after
                        if op=='readdress' and len(after)!=p['scope']['expected_total']:
                            run['state']='stopped_count_mismatch';break
                    _,record['final_scan']=self.base._scan(ch,p['gateway'])
                    if record['final_scan']['addresses']!=after:
                        run['state']='stopped_address_mismatch';break
                    record['readback_complete']=True
                    self._record('execution',ident,run,True)
                    if record.get('dispatch_error'):
                        run['state']='stopped_receipt_unknown';break
                else:
                    run['state']='reset_acknowledged_readback_captured' if op=='factory_reset' else 'completed_readback'
                    if op=='factory_reset':run['factory_defaults_verified']=False
                run['cancel_requested']=bool(cancelled())
            except CancelledBeforeWrite:run['state']='cancelled_before_write'
            except (Exception,KeyboardInterrupt) as exc:
                run.update(state='stopped_unknown' if run['write_intent'] else 'preflight_failed',error=str(exc) or type(exc).__name__)
            finally:
                run['finished_at']=time.time();self._record('execution',ident,run,True)
        return run
