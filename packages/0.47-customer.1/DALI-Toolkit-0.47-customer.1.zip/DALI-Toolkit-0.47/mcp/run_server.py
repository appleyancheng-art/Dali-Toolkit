from dali_mcp.__main__ import main
if __name__ == "__main__":
    main()
