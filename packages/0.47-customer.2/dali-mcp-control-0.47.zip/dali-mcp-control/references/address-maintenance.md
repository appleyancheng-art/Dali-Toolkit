# 交换、全量寻址与通道恢复出厂

仅在实际工具列表提供本文件所列接口时使用。0.46 不含这些接口；0.47 的现场范围以发布验收记录为准，不能由工具出现推断所有固件已验收。运行版本先看 `dali_status`，连接身份先看 `dali_check_connection`；新项目先搜索、选定网关。

## 分清六种请求

| 用户要做的事 | 入口 | 范围 |
|---|---|---|
| 改一个地址 | `dali_prepare_address_move` → `dali_apply_address_move` | 源地址移到空闲地址 |
| 删除一个地址 | `dali_prepare_address_removal` → `dali_apply_address_removal` | 单灯失去短地址，不等于恢复出厂 |
| 自动新增地址 | `dali_start_address_allocation_review` → `dali_start_address_allocation` | 当前通道所有无地址灯；不是搜索现有地址 |
| 交换两个地址 | `dali_start_address_swap_review` | 两个已占用地址互换 |
| 全部重新寻址 | `dali_start_channel_readdress_review` | 整条指定通道重新分配，可能丢失原映射和配置 |
| 恢复出厂 | `dali_start_factory_reset_review` | 上位机“重置所有数据”的 DALI 通道操作；不重置网关网络设置 |

前三项仍按 [地址管理](address-management.md) 和 [自动新增](address-allocation.md) 的已实现工具执行。用户只说删除某盏灯，不扩成整通道重置。用户要网关恢复出厂时，说明此工具不适用，不用通道重置代替。

## 后三项的共同流程

1. 明确网关、通道、操作范围。按会话已有授权执行，不为了工具的确认字符串重复向用户索要授权。未知的是范围、物理恢复要求或现场接线时，才补问缺失信息。
2. 正常关闭 ConfigMaster，避免两个客户端同时控制。保留原现场配置和状态目录；不结束不明归属的进程。
3. 调相应 `*_review`，保持服务存活，沿返回的 `operation_id` 轮询 `dali_get_address_maintenance`，直到 `active_in_this_process=false`。`reviewed` 仅表示只读备份完成，尚未操作设备。
4. 检查计划的通道、动作和备份覆盖。仅在任务专用配置开启 `enable_address_maintenance=true`，将 `allowed_address_maintenance_digest` 设为计划完整摘要，`allowed_address_maintenance_operations` 设为例如 `[{"operation":"swap","channel":1}]`。替换为当次范围，不照抄示例。配置在服务启动时读取；准备任务结束后可以正常关闭该服务，再以同一状态目录和任务配置启动执行服务。
5. `dali_start_address_maintenance(operation_id,confirmation)` 使用返回的原确认字符串。继续轮询原 ID，不能结束正在执行的 stdio 进程或另开同一任务。完成/异常后关闭任务专用写门。

通过随包 `client.py` 调用上述 review/start 时，客户端会自动保持原 stdio 会话、轮询到终态并取回完整证据；不要自己在“任务已启动”时结束它。未取得终态、日志缺失或中间停止都返回非零退出码，原日志保留，不能换日志名就重发。

`completed_readback` 表示本操作的占用/数量/受支持值检查通过，不证明硬件唯一身份。重置的成功回执与快照记录为 `reset_acknowledged_readback_captured`，`factory_defaults_verified=false`，不能声称所有厂家私有参数均已恢复默认。结合具体现场验收记录报告已核对字段。

## 交换地址

优先采用空闲地址作临时位置：A→空闲、B→A、临时→B；每步扫描并核对移动灯具，最后核对整条通道的受支持参数、分组、16 场景及实时输出。

满 64 地址时默认拒绝，不偷偷删除。只有现场明确确认总共 64 个物理设备、全部有地址且允许临时移除一个短地址时，才传 `allow_temporary_unaddressed=true, expected_total=64`。这条路径是移除 A→B 移到 A→增量分配找回 B 空位；新增针对整通道所有无地址设备，数量参数不能限制设备端范围。不能单凭扫描 64 地址或重复位图为 0 推断没有隐藏设备。0.47 满通道交换路径仅模拟通过；A 通道空闲地址中转交换已实测。

已完成交换需要换回来时，重新准备同一对地址的交换，先把新鲜备份与原成功记录中的交换结果比较，再执行。中途停止时，先取 `include_details=true` 查看每一步实际地址和读回；不能重新跑原计划或假装交换完整成功。必要的恢复要另建明确计划，不自动删除、重新寻址或恢复出厂。

## 全量寻址与恢复出厂

全量寻址 `expected_total` 是读回数量断言，不是设备侧数量上限。操作针对整条通道，包括尚无短地址的灯。完整原配置备份不包含可读的物理唯一编号；操作后即使仍是同样数量，也不能保证恢复每盏灯原来的地址、名称、场景或平面位置。

原地址排列必须保留而又缺乏独立物理对应方法时，不直接做全量寻址/重置。先安排单灯隔离或由用户明确接受重新编号，保留原备份。项目测试授权可覆盖写入，但不能把不可能的物理恢复说成已经保证。

1.6.11 的 A 通道现场重置会清除全部短地址，之后扫描为零地址不等于网关离线。原有灯失去短地址时不能再逐灯读取参数。用户需要重新投入使用且范围已获授权时，另建“自动新增”事务，再读取新地址下的配置；不重发重置，不把新增说成原物理映射恢复，也不在用户只要求清空时擅自重新编址。

任何超时、读回不一致、`stopped_*`、`worker_failed` 或 `execution_unavailable` 都保留原记录，先读现状，不重发。`dali_cancel_address_maintenance` 只阻止后续步骤，已发命令仍完成必要读回；它不回滚。换地址后旧名称、平面图、布局和旧计划不会自动迁移，必须刷新并重新确认对象。
