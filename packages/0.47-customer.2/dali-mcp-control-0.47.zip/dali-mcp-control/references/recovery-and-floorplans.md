# 0.46：恢复、结果与轻量平面图

先查看实际工具列表和 dali_status.version；旧版本没有这些入口。

## 连接与读取

dali_status 只报告配置、兼容策略、state_dir 和最近连接信息；用 dali_check_connection 做新的身份查询/握手。失败不等于掉电。原网关 DHCP/固件变化时 dali_reconnect_gateway(local_ips?,persist=false) 按配置 MAC 搜索；只有唯一匹配才切换，persist=true 会备份并更新启动配置。旧写开关会关闭；重新授权当前精确范围，不能直接复用失效计划。

1.6.9 保留原覆盖；1.6.11 支持实时/场景/组/参数，但禁用地址控制。未知固件可只读，发送层会拒绝所有控制，修改 expected_firmware 不能变成已验证。不要因为报版本错误就让客户刷网关固件。

未知地址清单先 dali_scan_existing；未满 64 地址用实际清单逐灯操作。read_actual 的 stopped_partial 包含 rows、pending_address、remaining_addresses 和只读重连证据；已读不是全量完成，空地址无应答不是全网关离线。整通道广播需完整 64 盏能力及渐变条件，失败时的扫描诊断可能也失败，不能用诊断推定成功。

## 写入结果与恢复

- 场景 verified=写后读回符合，unchanged=新读已符合而未写；outcome_unknown、verification_failed、缺失项均不能算成功。no_write_needed=true 表示本次无须写，不是写入失败。
- save_scene_batch 支持最多 1024 项。默认 invalid_policy=stop，先预检全部并备份后再写。validation_failed / preflight_failed 时查看 device_writes、pending、validation_errors；skip 仅在用户允许跳过时使用，completed_partial 不能说全部完成。
- 2700 与 2702 若 1000000//K 相同可视为等效；其他越界返回 nearest_legal_kelvin，但不能擅自修改用户目标或灯具极限。
- 保存失败先 get_scene_plan / read_scenes。dali_preview_scene_resume(plan_id) 新读原范围，再生成新计划；已到目标项不写，既不是原值也不是目标值的项为冲突。审阅新计划，沿现有授权应用；绝不直接重放原 apply。
- 参数 live output changed 可能是真实变化。查看 prepared/current 值，核对外部控制后重新准备，不降低保护或自动反复写。
- fade_time=0 可写/恢复，fade_rate=0 仍非法。扩展渐变未读取，码 0 不承诺瞬时；保留实时色温到位和广播未知渐变保护。

## 长任务和证据

包内 client.py 已对 start_parameter_batch / start_scene_save 等保持服务轮询至终态；自行实现客户端也必须保持原服务。--output-format jsonl（或 --progress-json）输出 event=progress/result。检查设备 state 和 readback，不能只看进程退出或客户端 returned。

完整响应写入 --output；服务记录在 dali_status.state_dir。get_blink/get_identification/get_parameter_batch 等可在同一状态目录跨进程查询。operations_count=0 才是空列表，不能把只含摘要视为记录不存在。取消依赖原进程中的活动 worker，磁盘上的 running 不证明还活着；不要启动新实例重播。

dali_capture_project 只读短暂失败有限重连。stopped_partial 后用 dali_resume_project_capture(project_id)，继续缺失字段，返回新 ID；旧记录不改。只支持新校验检查点，限定同 IP/MAC/固件、24 小时以内。保留各字段 captured_at，跨时点记录不能证明所有设备同时处于该状态；完成后才按原工程规则 import/diff/restore。

## 图片、地址标注与上位机写回

不需要先采集灯具工程。下面的本地图片工具仍在当前选定网关状态目录保存，避免项目混淆：

1. dali_import_floorplan_image(image_path,name,marks?) 导入绝对路径 PNG/JPEG，或 dali_capture_floorplan_image(name) 读取显式绑定上位机文件的磁盘底图+标记。后者不含未保存的内存编辑。
2. dali_get_floorplan_image(floorplan_id?) 查看或列出；dali_set_floorplan_marks(floorplan_id,marks,remove?) 增量建立新版本。坐标为原图归一化 x/y 0–1，ch=1/2、addr=0–63；不是屏幕像素，不默认标记已经物理核对。
3. dali_export_floorplan_image(floorplan_id,output_path,annotated=true) 导出带 A0/B63 等地址的 PNG；annotated=false 为底图。不会覆盖已有文件；样式由 Toolkit 绘制，不是原生截图。
4. 写回准备 dali_prepare_floorplan_image(floorplan_id,mode='merge')。同一底图保留未选标记；换图只能显式 replace，先说明会替换原生当前底图。图库可有多图，厂家应用只有一个活动图。
5. 用户已要求写回时关闭上位机，确认 configmaster_cache_file 精确绑定及 enable_native_floorplan_writes。dali_apply_floorplan_image(plan_id,confirmation) 备份原文件/图片，限 floorPlan 修改、读回；其他字段保持。准备可在程序运行时完成，提交仍必须关闭，不能绕过 guard。
6. dali_get_floorplan_image_plan 查证据；dali_prepare_floorplan_image_restore 生成条件恢复，再 apply。新 PNG 保留为证据、不删除原图。更晚的平面图修改产生冲突，不能用整份旧备份硬覆盖。

图片最大 40 MB、4000 万像素、单边 16384；PNG 非交错，JPEG 导入转 PNG 并应用 EXIF 方向，转换结果同样受大小限制。不暗中缩图改变坐标。旧 project 附件仍为 2 MB。写回完成仅证明磁盘读回；需要显示验证时重开上位机并按 Computer Use Skill 查看，不能说运行中已经同步。
